const express = require('express');
const fs = require('fs');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const authMiddleware=require('./middleware/auth');
const { stringify } = require('querystring');
const cors = require('cors');

//#region Variables y Constantes
const app=express();
app.use(express.json());
app.use(cors());

const JWT_SECRET='PRUEBA_2025';

const USER_FILE = './data/users.json';

const readUsers = () => JSON.parse(fs.readFileSync(USER_FILE,'utf-8'));
const writeUser = (users) => fs.writeFileSync(USER_FILE, JSON.stringify(users, null,2), 'utf-8');
//#endregion

//#region  login
app.post('/login',(req,res)=>{
    const {username,password}=req.body;
    let users=readUsers();
    const user=users.find(u=>u.username === username);
    if(!user) return res.status(400).json({msg: 'Usuario desconocido'});

    if(!bcrypt.compareSync(password, user.password)){
        return res.status(400).json({msg: 'Contraseña incorrecta'});
    }

    const token = jwt.sign({id: user.id, role: user.role}, JWT_SECRET, {expiresIn: '10m'});
    res.json({token});
});
//#endregion

//#region registroUsuarios 
app.post('/registroUsuarios',(req,res)=>{
    const {
        username,
        password,
        role,
        nombre,
        apellidoPaterno,
        apellidoMaterno,
        fechaNacimiento,
        correo,
        lugarNacimiento
    }=req.body;
    if(!username||!password || !nombre || !correo ) return res.status(400).json({msg: 'Faltan campos'});

    let users = readUsers();
    if(users.find(u=>u.username===username)){
        return res.status(400).json({msg:'El usuario ya se encuentra registrado.'});
    }

    const hashed=bcrypt.hashSync(password,10);
    users.push({id: Date.now().toString, 
        username,
        password: hashed,
        role: role || 'usuario',
        nombre,
        apellidoPaterno,
        apellidoMaterno,
        fechaNacimiento,
        correo,
        lugarNacimiento
    });
    writeUser(users);

    res.json({msg: 'Usuario registrado con exito'});
});
//#endregion

//#region GetUsuarios
app.get('/getUsuarios', authMiddleware(JWT_SECRET),(req, res)=>{
    let users = readUsers();
    user = users.map(u => {
    const { password, ...rest } = u;
    return rest;
    });
    res.json(users);
});
//#endregion

//#region editUsuario
app.put('/editUsuario/:id',authMiddleware(JWT_SECRET), (req, res)=>{
    const {id}=req.params;
    const {username, password, role}=req.body;
    const {user}=req;

    let users = readUsers();
    const index=users.findIndex(u=> u.id ===id);
    if(index===-1) return res.status(404).json({msg: 'El usuario no existe'});

    if(user.role !== 'admin' && user.id !== id){
        return res.status(403).json({msg:'No autorizado'});
    }

    if (username) users[index].username = username;
    if (password) users[index].password = bcrypt.hashSync(password, 10);
    if (role && user.role === 'admin') users[index].role = role;

    writeUsers(users);
    res.json({ msg: 'Los cambios han sido guardados con exito' });
});
//#endregion

//#region deleteUsuarios
app.delete('/deleteUsuarios/:id', authMiddleware(JWT_SECRET), (req, res)=>{
    const {id}=req.params;
    const {user}=req;

    let users =readUsers();
    const index = users.findIndex(u=> u.id=== id);
    if(index===-1) return res.status(404).json({msg: 'El usuario no existe'});

    if(user.role !== 'admin' && user.id !== id){
        return res.status(403).json({msg: 'No tiene los permisos para esta accion'});
    }

    users.splice(index,1);
    writeUser(users);

    res.json({msg: 'Usuario eliminado'});
});
//#endregion

app.listen(3001, ()=>console.log('API corriendo en http://localhost:3001'));