require('dotenv').config();
const jwt = require('jsonwebtoken');

function generateTestToken(){
    const payload={
        issuer: 'WebhookCliente',
        permissions: ['webhook:post']
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, {expiresIn: '10m'});
    console.log('TOKEN:', token);
}

function generateToken(user){
    const payload = {
        userId: user.id,
        username: user.username,
        permissions:['webhook:post']
    };

    return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '24h'});
}

module.exports= generateToken;