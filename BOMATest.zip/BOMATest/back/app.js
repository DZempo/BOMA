require('dotenv').config();
const express = require('express');

const webhookRoutes=require('./routes/webhook');
const loginRoutes=require('./routes/login');
const cardInRoutes=require('./routes/cardIn');
const cashInRoutes=require('./routes/cashIn');
const availablePromotionsRoutes=require('./routes/availablePromotions');
const availableArticlesRoutes=require('./routes/availableArticles');
const changePromotionRoutes=require('./routes/changePromotion');
const changeArticlesRoutes=require('./routes/changeArticles');
const infoTicketRoutes=require('./routes/infoTicket');

const app = express();
app.use(express.json());
app.use('/webhook', webhookRoutes);
app.use('/login',loginRoutes);
app.use('/cardIn', cardInRoutes);
app.use('/cashIn', cashInRoutes);
app.use('/availablePromotions', availablePromotionsRoutes);
app.use('/availableArticles', availableArticlesRoutes);
app.use('/changePromotion', changePromotionRoutes);
app.use('/changeArticles', changeArticlesRoutes);
app.use('/infoTicket', infoTicketRoutes);

const PORT = process.env.PORT || 80;
app.listen(PORT, ()=>{
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});