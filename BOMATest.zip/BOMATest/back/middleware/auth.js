const jwt = require('jsonwebtoken');

module.exports = (secret) => (req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) return res.status(401).json({ msg: 'Token faltante' });

  try {
    const decoded = jwt.verify(token.split(' ')[1], secret);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ msg: 'Token inválido o expirado' });
  }
};