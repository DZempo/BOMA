import {useState} from 'react';

export default function Profile(){
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const token = localStorage.getItem('token');

    const edit = async() =>{
        //Para efectos de la demo se decodificara el token para obtener el ID 
        const payload = JSON.parse(atob(token.split('.')[1]));
        const id=payload.id;

        await fetch(`http://localhost:3001/editUsuario/${id}`,{
            method: 'PUT',
            headers: {'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`},
            body: JSON.stringify({username, password}),
        });

        alert('Perfil actualizado');
    };

    const del = async() =>{
        const payload = JSON.parse(atob(token.split('.')[1]));
        const id = payload.id;

        await fetch(`http://localhost:3001/deleteUsuarios/${id}`,{
            method: 'DELETE',
            headers: {'Authorization':`Bearer ${token}`},
        });
        alert('Perfil eliminado');
        localStorage.removeItem('token');
    };
    return (
        <div>
        <h2>Perfil</h2>
        <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Nuevo usuario" />
        <input value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="Nueva contraseña" />
        <button onClick={edit}>Actualizar</button>
        <button onClick={del}>Eliminar mi cuenta</button>
        </div>
    );
}