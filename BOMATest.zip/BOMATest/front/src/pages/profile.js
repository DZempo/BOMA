import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Form.css';

export default function Profile() {
  const nav = useNavigate();
  const token = localStorage.getItem('token');
  const [original, setOriginal] = useState(null);
  const [form, setForm] = useState({
    username: '',
    password: '',
    nombre: '',
    apellidoPaterno: '',
    apellidoMaterno: '',
    fechaNacimiento: '',
    correo: '',
    lugarNacimiento: ''
  });
  const [editable, setEditable] = useState(false);
  const [userId, setUserId] = useState(null);

  // Al cargar, buscar datos del usuario
  useEffect(() => {
    const loadProfile = async () => {
      const res = await fetch('http://localhost:3001/getUsuarios', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      const payload = JSON.parse(atob(token.split('.')[1]));
      const me = data.find(u => u.username === payload.username);
      if (me) {
        setForm({
          username: me.username,
          password: '', // vacío para nueva contraseña opcional
          nombre: me.nombre,
          apellidoPaterno: me.apellidoPaterno,
          apellidoMaterno: me.apellidoMaterno,
          fechaNacimiento: me.fechaNacimiento,
          correo: me.correo,
          lugarNacimiento: me.lugarNacimiento
        });
        setOriginal({
          username: me.username,
          password: '',
          nombre: me.nombre,
          apellidoPaterno: me.apellidoPaterno,
          apellidoMaterno: me.apellidoMaterno,
          fechaNacimiento: me.fechaNacimiento,
          correo: me.correo,
          lugarNacimiento: me.lugarNacimiento
        });
        setUserId(me.id);
      } else {
        alert('Usuario no encontrado');
        nav('/login');
      }
    };
    loadProfile();
  }, [token, nav]);

  const update = (e) => {
    if (!e.target || !e.target.name) return;
    const updated = { ...form, [e.target.name]: e.target.value };
    setForm(updated);
    setEditable(JSON.stringify(updated) !== JSON.stringify(original));
  };

  const saveChanges = async () => {
    try {
      await fetch(`http://localhost:3001/editUsuario/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(form)
      });
      alert('Cambios guardados');
      setOriginal(form);
      setEditable(false);
    } catch {
      alert('Error al guardar');
    }
  };

  const deleteAccount = async () => {
    if (!window.confirm('¿Estás seguro de que quieres eliminar tu cuenta?')) return;
    try {
      await fetch(`http://localhost:3001/deleteUsuarios/${userId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      alert('Cuenta eliminada');
      localStorage.removeItem('token');
      nav('/login');
    } catch {
      alert('Error al eliminar la cuenta');
    }
  };

  if (!original) return <div className="form-container"><div className="form-card"><p>Cargando perfil...</p></div></div>;

  return (
    <div className="form-container">
      <div className="form-card">
        <h2>Mi Perfil</h2>
        <input className="input" name="nombre" value={form.nombre} onChange={update} placeholder="Nombre" />
        <input className="input" name="apellidoPaterno" value={form.apellidoPaterno} onChange={update} placeholder="Apellido Paterno" />
        <input className="input" name="apellidoMaterno" value={form.apellidoMaterno} onChange={update} placeholder="Apellido Materno" />
        <input className="input" name="username" value={form.username} readOnly placeholder="Usuario" />
        <input className="input" name="password" type="password" value={form.password} onChange={update} placeholder="Nueva Contraseña (opcional)" />
        <input className="input" name="correo" value={form.correo} onChange={update} placeholder="Correo Electrónico" />
        <input className="input" name="lugarNacimiento" value={form.lugarNacimiento} onChange={update} placeholder="Lugar de Nacimiento" />
        <input className="input" name="fechaNacimiento" type="date" value={form.fechaNacimiento} onChange={update} />
        <button className="button" onClick={saveChanges} disabled={!editable}>Guardar Cambios</button>
        <button className="button" style={{backgroundColor:'red'}} onClick={deleteAccount}>Eliminar Cuenta</button>
      </div>
    </div>
  );
}
