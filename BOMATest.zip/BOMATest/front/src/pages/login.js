import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Form.css';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const nav = useNavigate();

  const login = async () => {
    try {
      const res = await fetch('http://localhost:3001/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (data.token) {
        localStorage.setItem('token', data.token);
        nav('/users');
      } else {
        alert(data.msg);
      }
    } catch (error) {
      alert('Error al contactar al servidor');
    }
  };

  const goRegister = () => {
    nav('/register');
  };

  return (
    <div className="form-container">
      <div className="form-card">
        <h2>Login</h2>
        <input
          className="input"
          value={username}
          onChange={e => setUsername(e.target.value)}
          placeholder="Usuario"
        />
        <input
          className="input"
          value={password}
          onChange={e => setPassword(e.target.value)}
          type="password"
          placeholder="Contraseña"
        />
        <button className="button" onClick={login}>Login</button>
        <button className="button" onClick={goRegister}>Registrarse</button>
      </div>
    </div>
  );
}
