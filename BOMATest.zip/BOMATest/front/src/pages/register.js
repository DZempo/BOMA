import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Form.css';

export default function Register() {
  const nav = useNavigate();
  const [form, setForm] = useState({
    username: '',
    password: '',
    nombre: '',
    apellidoPaterno: '',
    apellidoMaterno: '',
    fechaNacimiento: '',
    correo: '',
    lugarNacimiento: ''
  });

  const update = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const register = async () => {
    try {
      const res = await fetch('http://localhost:3001/registroUsuarios', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok) {
        alert('Registro exitoso');
        nav('/login');
      } else {
        alert(data.msg);
      }
    } catch {
      alert('Error al contactar al servidor');
    }
  };

  return (
    <div className="form-container">
      <div className="form-card">
        <h2>Registro de Usuario</h2>
        <input className="input" name="nombre" value={form.nombre} onChange={update} placeholder="Nombre" />
        <input className="input" name="apellidoPaterno" value={form.apellidoPaterno} onChange={update} placeholder="Apellido Paterno" />
        <input className="input" name="apellidoMaterno" value={form.apellidoMaterno} onChange={update} placeholder="Apellido Materno" />
        <input className="input" name="username" value={form.username} onChange={update} placeholder="Usuario" />
        <input className="input" name="password" type="password" value={form.password} onChange={update} placeholder="Contraseña" />
        <input className="input" name="correo" value={form.correo} onChange={update} placeholder="Correo Electrónico" />
        <input className="input" name="lugarNacimiento" value={form.lugarNacimiento} onChange={update} placeholder="Lugar de Nacimiento" />
        <input className="input" name="fechaNacimiento" type="date" value={form.fechaNacimiento} onChange={update} />
        <button className="button" onClick={register}>Registrarse</button>
        <button className="button" onClick={() => nav('/login')}>Volver a Login</button>
      </div>
    </div>
  );
}
