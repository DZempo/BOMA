import { useEffect, useState } from 'react';
import './Table.css';

export default function Users() {
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState('');
  const token = localStorage.getItem('token');

  const load = async () => {
    const res = await fetch('http://localhost:3001/getUsuarios', {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await res.json();
    setUsers(data);
  };

  useEffect(() => { load(); }, []);

  const filtered = users.filter(u =>
    Object.values(u).some(v =>
      String(v).toLowerCase().includes(filter.toLowerCase())
    )
  );

  return (
    <div className="table-container">
      <h2>Usuarios Registrados</h2>
      <input
        className="input-filter"
        placeholder="Buscar..."
        value={filter}
        onChange={e => setFilter(e.target.value)}
      />
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Apellido Paterno</th>
            <th>Apellido Materno</th>
            <th>Usuario</th>
            <th>Correo</th>
            <th>Lugar Nacimiento</th>
            <th>Fecha Nacimiento</th>
            <th>Rol</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(u => (
            <tr key={u.id}>
              <td>{u.nombre}</td>
              <td>{u.apellidoPaterno}</td>
              <td>{u.apellidoMaterno}</td>
              <td>{u.username}</td>
              <td>{u.correo}</td>
              <td>{u.lugarNacimiento}</td>
              <td>{u.fechaNacimiento}</td>
              <td>{u.role}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
